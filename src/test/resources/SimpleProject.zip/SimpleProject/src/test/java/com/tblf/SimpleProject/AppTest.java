package com.tblf.SimpleProject;

import org.junit.Test;

public class AppTest {
    
	@Test
	public void testApp() {
		new App().method();
	}

	@Test
	public void testApp2() {
		new App("String").method();
	}
}
